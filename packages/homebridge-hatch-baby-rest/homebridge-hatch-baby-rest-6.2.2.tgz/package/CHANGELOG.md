# Changelog

## 6.2.2

### Patch Changes

- [`d1503e4`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/d1503e498aa7b92c381c50b7c4cf29e79b4a52dd) Thanks [@dgreif](https://github.com/dgreif)! - Bump actions verisons for trusted npm release

## 6.2.1

### Patch Changes

- [`d34bfe4`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/d34bfe424c21b5c34875182e15cb11a13c2ee72f) Thanks [@dgreif](https://github.com/dgreif)! - Fix light switch toggle not setting brightness to 0 when turned off

- [`1e80701`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/1e807016c57eae449fad35caaa393078d4acd4ac) Thanks [@dgreif](https://github.com/dgreif)! - Refresh aws token every 50 minutes instead of 8 hours

## 6.2.0

### Minor Changes

- [`199ee24`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/199ee247f6c804effd40a182dfa83793fb9b7867) Thanks [@dgreif](https://github.com/dgreif)! - Add support for the Hatch Baby (Rest Baby) device

- [`86a8db1`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/86a8db13d57bb0a7994d944bcf0b4d91848f0a8e) Thanks [@dgreif](https://github.com/dgreif)! - Add support for Restore 3 (restoreV5)

### Patch Changes

- [`a3e7183`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/a3e718332ce26e1fdee8f51b14cfde06c9bd5029) Thanks [@dgreif](https://github.com/dgreif)! - Update dependencies

- [`5f8cc47`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/5f8cc47cc7cba940696eb8a39ab0ea849fc9cf4c) Thanks [@cameronsjo](https://github.com/cameronsjo)! - Fix Restore IoT on/off commands by setting `paused` to `false`

## 6.1.0

### Minor Changes

- [`9ceacdd`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/9ceacdddbcd94dc9f41639e7afb2b465eeef4ab9) Thanks [@mkaz](https://github.com/mkaz)! - Failed network requests will retry less often with exponential backoff up to 1 minute

### Patch Changes

- [`73d0dcd`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/73d0dcdbab038636a3f2656d2d90db7cb1209925) Thanks [@dgreif](https://github.com/dgreif)! - Update dependencies

## 6.0.0

### Major Changes

- [`f06010a`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/f06010ad206baaf5f66fba209f304334e9791b23) Thanks [@dgreif](https://github.com/dgreif)! - Converted from commonjs to esm

- [`5fd5731`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/5fd5731324f7ac998b12ea0cdf8fd7fbaeebb612) Thanks [@dgreif](https://github.com/dgreif)! - Drop Node 18 support and add Node 22 and 24

### Minor Changes

- [`fc58f31`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/fc58f31c4f5831a1d9c95363784a8b665f17623a) Thanks [@jbryandev](https://github.com/jbryandev)! - Add support for Restore 2

### Patch Changes

- [`2caf9e0`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/2caf9e07c8a7ce15ba12ae475708b3abea51f3e6) Thanks [@dgreif](https://github.com/dgreif)! - Updated all dependencies

- [`eded6ca`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/eded6ca1705ba91d1dc841609ca272f42a8e014f) Thanks [@dgreif](https://github.com/dgreif)! - Handle login failures more gracefully

- [`74a0245`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/74a02451598051ded6b23abebd0f0a1a0db0d4f6) Thanks [@dgreif](https://github.com/dgreif)! - Enable erasableSyntaxOnly TypeScript option

## 6.0.0-beta.1

### Patch Changes

- [`eded6ca`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/eded6ca1705ba91d1dc841609ca272f42a8e014f) Thanks [@dgreif](https://github.com/dgreif)! - Handle login failures more gracefully

## 6.0.0-beta.0

### Major Changes

- [`f06010a`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/f06010ad206baaf5f66fba209f304334e9791b23) Thanks [@dgreif](https://github.com/dgreif)! - Converted from commonjs to esm

- [`5fd5731`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/5fd5731324f7ac998b12ea0cdf8fd7fbaeebb612) Thanks [@dgreif](https://github.com/dgreif)! - Drop Node 18 support and add Node 22 and 24

### Minor Changes

- [`fc58f31`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/fc58f31c4f5831a1d9c95363784a8b665f17623a) Thanks [@jbryandev](https://github.com/jbryandev)! - Add support for Restore 2

### Patch Changes

- [`2caf9e0`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/2caf9e07c8a7ce15ba12ae475708b3abea51f3e6) Thanks [@dgreif](https://github.com/dgreif)! - Updated all dependencies

- [`74a0245`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/74a02451598051ded6b23abebd0f0a1a0db0d4f6) Thanks [@dgreif](https://github.com/dgreif)! - Enable erasableSyntaxOnly TypeScript option

## 5.0.2

### Patch Changes

- [`c2b72ac`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/c2b72ac07b4471fe1c3cf00a2d62282e132659b4) Thanks [@dgreif](https://github.com/dgreif)! - Add support for Node 22

## 5.0.1

### Patch Changes

- [`74bc9ee`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/74bc9eeef7741311512aca5375924242f4bbbc2d) Thanks [@dgreif](https://github.com/dgreif)! - Prepare for Homebridge v2

## 5.0.0

### Major Changes

- [`fdedff7`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/fdedff7638fd796a8394c17eaa84882a624c15bf) Thanks [@dgreif](https://github.com/dgreif)! - Dropped support for Node 16. Please update to Node 18 or Node 20. This allows us to drop a dependency on `got` and use the native `fetch` from Node.js.

## 4.3.4

### Patch Changes

- [`7d87cfd`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/7d87cfdb357f6ef05d84378513d26ddb222d506e) Thanks [@dgreif](https://github.com/dgreif)! - Updated dependencies

## 4.3.3

### Patch Changes

- [`b8d93fa`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/b8d93fa68989635174b5087d49edca727833bd1a) Thanks [@dgreif](https://github.com/dgreif)! - Only fetch known products to avoid accidentally sending a bad device request. Should fix #125

## 4.3.2

### Patch Changes

- [`71eb805`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/71eb8053e214275c460e6b85e98f5f2c927b9690) Thanks [@dgreif](https://github.com/dgreif)! - Fetch both known and unknown device types in case Hatch does not give us a complete list of user devices. Might fix #123

- [`52cfcf1`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/52cfcf1126e570ecd80853f66dedde70d5110bfd) Thanks [@dgreif](https://github.com/dgreif)! - Mark `grow` as a known but unsupported device

## 4.3.1

### Patch Changes

- [`072f68d`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/072f68d7d63335fbac080fee63774f753274a0f7) Thanks [@dgreif](https://github.com/dgreif)! - Fetch all products for the account, rather than just fetching known device types. This will allow us to log info for new unknown device types.

## 4.3.0

### Minor Changes

- [`53769b7`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/53769b79e06f2608d262dd9fbea1ff11ca861e96) Thanks [@dgreif](https://github.com/dgreif)! - Add `debug` option which logs unknown product details

### Patch Changes

- [`d220117`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/d220117174390d203f95a83848bf719df68f1b52) Thanks [@dgreif](https://github.com/dgreif)! - Prevent unsupported device logging for `alexa` devices

## 4.2.0

### Minor Changes

- [`f434fd7`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/f434fd771ae478263101e444c3f8c1cdf2df9b7d) Thanks [@dgreif](https://github.com/dgreif)! - Add support for Restore 2 (restoreIot). Note, this is untested so please open an issue if you find the device does not work as expected.

## 4.1.0

### Minor Changes

- [`9e1f253`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/9e1f25340c9811bb3acb29b0743930a09d897f49) Thanks [@dgreif](https://github.com/dgreif)! - Support Node 20

- [`512fdfe`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/512fdfeda576e871c0d99088b91990a094fe19ac) Thanks [@dgreif](https://github.com/dgreif)! - Add support for Rest Gen 2 with updated routines

### Patch Changes

- [`c4f2596`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/c4f259692ef546892d304caeb19038ebd8b78f8c) Thanks [@dgreif](https://github.com/dgreif)! - Fix bug where state was only partially retained after receiving remote changes

- [`171696f`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/171696f50b43ea130734e0c63978e59f21db7ed2) Thanks [@dgreif](https://github.com/dgreif)! - Update dependencies

## 4.0.1

### Patch Changes

- [`868d445`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/868d4450fd386b83efafc891a5e67fe582074544) Thanks [@dgreif](https://github.com/dgreif)! - Add user agent to API calls, which should resolve internal server errors in #107

## 4.0.0

### Major Changes

- [`b2a7958`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/b2a795881fcc7c82ca8b51a02fab1e46d8fa13d9) Thanks [@dgreif](https://github.com/dgreif)! - Require homebridge 1.5.1 or newer

- [`b2a7958`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/b2a795881fcc7c82ca8b51a02fab1e46d8fa13d9) Thanks [@dgreif](https://github.com/dgreif)! - Require node 16 or 18

- [`d70055f`](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/d70055ff021bbf7b0ee2bbcddebfac401a65aa13) Thanks [@dgreif](https://github.com/dgreif)! - Bluetooth versions of the Hatch Rest have been moved to the `homebridge-hatch-rest-bluetooth` plugin. Configuration for these lights will automatically be migrated the first time you run homebridge after updating to verison 4. You will need to manually install this new plugin for the lights to continue working, and automations related to these lights will need to be recreated. If you _only_ have bluetooth lights, you can uninstall the `homebridge-hatch-baby-rest` plugin after migrating. These bluetooth lights require complicated dependencies and are fundementally different from the WiFi based lights, so I've decided to maintain them separately moving forward.

## [3.4.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.3.0...v3.4.0) (2022-09-10)

### Features

- add Rest+ 2nd Gen ([5d3a787](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/5d3a78755a07d897a13b99425a8568dc655bbb0a))

### Bug Fixes

- remove restoreIot ([8966623](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/896662358a4f57e38c717dee8ff49f67868adf6c)), closes [#74](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/74)

### [3.3.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.3.0...v3.3.1) (2022-05-28)

### Bug Fixes

- remove restoreIot ([2e3d1ad](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/2e3d1ad93f844aade5cbceac5b887862c83bf663)), closes [#74](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/74)

## [3.3.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.5...v3.3.0) (2022-05-08)

### Features

- rest 2nd gen support ([ea30705](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/ea307057b14ac0f3b115901129fac5fe6f7e5a4c))

### Bug Fixes

- log unsupported products ([1d093cb](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/1d093cb9b99e53ac706b2b2d385d8eb88ef188ea))
- update dependencies ([c1d5073](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/c1d507300bba4a47fa41fef701082aaa74c88858))
- update dependencies ([0f29b3d](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/0f29b3dea167ddcf5dd7170c7dbf27b2abe4f2af))

## [3.3.0-beta.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.3.0-beta.0...v3.3.0-beta.1) (2021-12-27)

## [3.3.0-beta.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.5...v3.3.0-beta.0) (2021-12-26)

### Features

- rest 2nd gen support ([efdf49d](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/efdf49d0e75a386eb1908d94079bc2bb7ea0daba))

### [3.2.5](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.4...v3.2.5) (2021-11-27)

### Bug Fixes

- update dependencies ([a1c7d07](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/a1c7d07963369f725ad7f4086c62243fbd92e938))

### [3.2.4](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.3...v3.2.4) (2021-09-18)

### Bug Fixes

- connect with aws iot before returning devices ([2370896](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/237089636a1988284b10caf24b6cf5625f0efeb3)), closes [#61](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/61)
- correct rounding for percentage conversion ([85f8013](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/85f801334e69d961cd34033c0bd74b2a5b0d9059))
- refresh iot client every 8 hours ([1f114a5](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/1f114a5c918e2a93ed0514333a0078a8a462e549)), closes [#59](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/59)
- typo in homebridge logs ([3b0f0c1](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/3b0f0c1be3ee2a3a12d7a2104282935c1bfecc8c))
- update dependencies ([979cdc7](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/979cdc71122ca631e11102888e9ce4fb517bf0aa))

### [3.2.3](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.2...v3.2.3) (2021-08-15)

### Bug Fixes

- update dependencies ([4eee7e4](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/4eee7e452f20362c904eee68c25083ba95bbc405))

### [3.2.2](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.1...v3.2.2) (2021-05-17)

### [3.2.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.2.0...v3.2.1) (2021-05-17)

### Bug Fixes

- update dependencies ([2bd1414](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/2bd141413c459eaa0e8ec66cbf856cf2c588bdfc))

## [3.2.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.1.0...v3.2.0) (2021-04-10)

### Features

- hatch restore support ([d22cdfa](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/d22cdfae21dc076af9df3060439a2e96dbb6e4c9)), closes [#32](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/32)

### Bug Fixes

- update dependencies ([1da2c1d](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/1da2c1d910068e253f66b2861462689def39d342))

## [3.1.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v3.0.0...v3.1.0) (2021-03-06)

### Features

- rest mini support ([705da04](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/705da043dd5fb3def2ef24559535b963783e306a))

### Bug Fixes

- **rest+:** handle "no color" selection from hatch app ([b1a8014](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/b1a801464419c47ee2608633c9209ea80902a879)), closes [#45](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/45)
- update dependencies ([9106508](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/9106508a4cd5426208fdf8d4af15b5e947df62cb))

## [3.0.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.2.1...v3.0.0) (2021-02-06)

### ⚠ BREAKING CHANGES

- v3 includes a number of breaking changes. Please see https://github.com/dgreif/homebridge-hatch-baby-rest/wiki/Upgrading-from-v2-to-v3 for details

### Features

- unified platform config for rest and rest+ ([8902516](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/89025164d36eefcc0f97572a652f302728d46e3d))
- **rest:** separate power, light and sound accessories ([f3ddba2](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/f3ddba261658209c0ca98166d5296da123a6802a))
- **rest+:** separate power, light and sound accessories ([55617e5](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/55617e5c78565c6068143fdb7b34401c42dceb70))

### Bug Fixes

- automatically migrate rest accessories to platform ([d82ad32](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/d82ad32ca6623300fae137a75dbc6c5bd17c4b40))

### [2.2.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.2.0...v2.2.1) (2021-01-29)

## [2.2.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.1.0...v2.2.0) (2021-01-29)

### Features

- use mac address as serial number ([a7ee3f6](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/a7ee3f601bb20e351aa12d6eafbcb64e07fbc998)), closes [#42](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/42)

## [2.1.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.0.5...v2.1.0) (2020-11-14)

### Features

- **rest+:** `alwaysRainbow` option ([016bcac](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/016bcac7339b13762ef67f9c4113e0dec7aed8bb))

### Bug Fixes

- **rest+:** handle update requests serially ([f08f2b9](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/f08f2b9e76f73075546420cffce2b31d3c900078))
- only allow rest+ via platform ([de0e4f1](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/de0e4f1e6adfc83a33c21dc7163bbaa560cbc7e8)), closes [#32](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/32)
- only apply state updates to target device ([7635d32](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/7635d32f662a508e97a647fcd2726b79545ba4a0)), closes [#28](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/28)

### [2.0.5](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.0.4...v2.0.5) (2020-09-13)

### [2.0.4](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.0.3...v2.0.4) (2020-06-05)

### [2.0.3](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.0.2...v2.0.3) (2020-06-02)

### Bug Fixes

- create new mqtt client when auth expires ([65d0f33](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/65d0f33ae62ef434daa9160451ede8b53102e226)), closes [#8](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/8)

### [2.0.2](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.0.1...v2.0.2) (2020-05-12)

### [2.0.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v2.0.0...v2.0.1) (2020-04-08)

### Bug Fixes

- prevent noble from loading if not used ([71deda8](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/71deda858423185f24d04e8434811214cb16105e)), closes [#12](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/12)

## [2.0.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.3.1...v2.0.0) (2020-04-05)

### ⚠ BREAKING CHANGES

- Node 10+ now required

### Features

- add `showAsSwitch` option to hbr accessory ([0f83328](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/0f833281ae06f50f031343dcae135bc4c53fd720)), closes [#11](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/11)

- update minimum node version to 10 ([ea1837e](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/ea1837e031f2324bc82b6e92fc47aafe70441351))

### [1.3.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.3.0...v1.3.1) (2020-02-29)

### Bug Fixes

- allow rest+ lights to be removed with `removeAll` ([ed0b01e](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/ed0b01ebf94e41fb49f816a14a237f0474fc1d55))

## [1.3.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.2.0...v1.3.0) (2020-02-27)

### Features

- color picker for hbr+ ([4855330](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/48553302174b77c8a6152d69f7eca07ee60156a8))

## [1.2.0](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.8...v1.2.0) (2020-01-06)

### Features

- hatch baby rest+ support ([bc808b3](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/bc808b3f3943e6644b0c401944ae017a7f891ff0)), closes [#1](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/1)

### [1.1.8](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.7...v1.1.8) (2019-12-18)

### Bug Fixes

- **osx:** assume correct device if address is unknown ([1c892c5](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/1c892c5bcce13332dc215ed855a210ff23505b14)), closes [#4](https://github.com/dgreif/homebridge-hatch-baby-rest/issues/4)

### [1.1.7](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.6...v1.1.7) (2019-10-05)

### Bug Fixes

- remove initial connect call ([412f028](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/412f028))

### [1.1.6](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.5...v1.1.6) (2019-10-05)

### Bug Fixes

- revert reconnect logic ([27c3c10](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/27c3c10))
- throw error when service or characteristic is not found ([b50148d](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/b50148d))

### [1.1.5](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.4...v1.1.5) (2019-09-29)

### Bug Fixes

- add back reconnect logic ([a8a2e23](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/a8a2e23))

### [1.1.4](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.3...v1.1.4) (2019-09-26)

### Bug Fixes

- only connect while interacting ([7d06388](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/7d06388))

### [1.1.3](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.2...v1.1.3) (2019-09-26)

### Bug Fixes

- strip mac address and service ids for cross platform compatibility ([7eefc38](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/7eefc38))

### [1.1.2](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.1...v1.1.2) (2019-09-26)

### [1.1.1](https://github.com/dgreif/homebridge-hatch-baby-rest/compare/v1.1.0...v1.1.1) (2019-09-25)

## 1.1.0 (2019-09-25)

### Features

- hatch baby rest homebridge plugin ([956c56f](https://github.com/dgreif/homebridge-hatch-baby-rest/commit/956c56f))
